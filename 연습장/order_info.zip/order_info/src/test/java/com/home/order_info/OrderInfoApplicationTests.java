package com.home.order_info;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
