package com.home.order_info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderInfoApplication.class, args);
	}

}
