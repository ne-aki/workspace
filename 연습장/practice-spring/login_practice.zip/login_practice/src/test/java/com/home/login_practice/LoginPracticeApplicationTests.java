package com.home.login_practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
