package com.home.login_practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginPracticeApplication.class, args);
	}

}
