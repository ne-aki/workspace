package com.home.practice_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
