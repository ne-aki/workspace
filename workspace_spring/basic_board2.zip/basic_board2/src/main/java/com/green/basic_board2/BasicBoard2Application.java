package com.green.basic_board2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicBoard2Application {

	public static void main(String[] args) {
		SpringApplication.run(BasicBoard2Application.class, args);
	}

}
