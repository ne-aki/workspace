package com.green.basic_member;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicMemberApplicationTests {

	@Test
	void contextLoads() {
	}

}
