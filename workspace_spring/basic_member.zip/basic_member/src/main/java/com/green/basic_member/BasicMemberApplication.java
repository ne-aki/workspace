package com.green.basic_member;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicMemberApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicMemberApplication.class, args);
	}

}
