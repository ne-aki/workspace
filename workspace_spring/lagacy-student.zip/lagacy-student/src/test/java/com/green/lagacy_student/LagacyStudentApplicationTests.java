package com.green.lagacy_student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LagacyStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
