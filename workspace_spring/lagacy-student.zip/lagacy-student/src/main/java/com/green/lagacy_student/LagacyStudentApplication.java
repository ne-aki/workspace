package com.green.lagacy_student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LagacyStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(LagacyStudentApplication.class, args);
	}

}
