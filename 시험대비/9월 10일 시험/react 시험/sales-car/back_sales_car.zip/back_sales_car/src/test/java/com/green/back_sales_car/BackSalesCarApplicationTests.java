package com.green.back_sales_car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackSalesCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
