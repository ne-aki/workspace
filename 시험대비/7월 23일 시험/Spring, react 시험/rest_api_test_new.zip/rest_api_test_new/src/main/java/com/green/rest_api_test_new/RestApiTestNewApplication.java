package com.green.rest_api_test_new;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiTestNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiTestNewApplication.class, args);
	}

}
