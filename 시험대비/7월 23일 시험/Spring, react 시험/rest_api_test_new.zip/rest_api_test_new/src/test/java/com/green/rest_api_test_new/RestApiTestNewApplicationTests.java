package com.green.rest_api_test_new;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiTestNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
